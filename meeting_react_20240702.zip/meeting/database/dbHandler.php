<?php
require_once 'object.php';

class DbHandler {

    private $conn;

    function __construct() {
        require_once 'dbConnect.php';
        // opening db connection
        $db = new dbConnect();
        $this->conn = $db->connect();
    }

    function _backMdf($arrMdf, $sql) {
       try {
            if(count($arrMdf) > 0) {
              $this->conn->beginTransaction();
              $stmt = $this->conn->prepare( $sql) or die($this->conn->error.__LINE__);

              foreach ($arrMdf as $row) {
                foreach ($row as $cols => $value) {
                  $stmt->bindValue(":{$cols}",$value);
                }
                $stmt->execute();
              }

              $this->conn->commit();
              return true;
            } else {
              return false;
            }
        }
        catch(PDOException $e) {
          $this->conn->rollback();
          echo "Error: " . $e->getMessage();
          return false;
        }
    }


    /*============================
    * Users handler
    ==============================*/
    public function findUser($uId) {
    	$stmt = $this->conn->prepare("SELECT * FROM users WHERE userID = :uId" ) or die($this->conn->error.__LINE__);
    	$stmt->setFetchMode(PDO::FETCH_ASSOC);
    	$stmt->bindParam('uId',$uId);
    	$stmt->execute();
    	return $stmt->fetch();
    }

    public function findUserByEmail($email) {
      $stmt = $this->conn->prepare("SELECT * FROM users WHERE userEmail = :email" ) or die($this->conn->error.__LINE__);
      $stmt->setFetchMode(PDO::FETCH_ASSOC);
      $stmt->bindParam('email',$email);
      $stmt->execute();
      return $stmt->fetch();
    }

    public function findAllUsers() {
    	$stmt = $this->conn->prepare("SELECT * FROM users" ) or die($this->conn->error.__LINE__);
    	$stmt->setFetchMode(PDO::FETCH_ASSOC);
    	$stmt->execute();
    	return $stmt->fetchAll();
    }

    public function addUsers($arrUsers) {
      $sql = "INSERT INTO users (userName, userEmail, userDep, isActive) values (:name, :email, :dep, true)";
      return $this->_backMdf($arrUsers, $sql);
    }

    public function updateUsers($arrUsers) {
      $sql = "UPDATE users set userName=:name, userEmail=:email, userDep=:dep WHERE userID=:uId";
      return $this->_backMdf($arrUsers, $sql);
    }

    public function deleteUsers($arrUid) {
      $sql = "DELETE from users WHERE userID=:uId";
      return $this->_backMdf($arrUid, $sql);
    }



    /*============================
    * Rooms handler
    ==============================*/
    public function findRoom($rId) {
      $stmt = $this->conn->prepare("SELECT * FROM rooms WHERE roomID = :rId" ) or die($this->conn->error.__LINE__);
      $stmt->setFetchMode(PDO::FETCH_ASSOC);
      $stmt->bindParam('rId',$rId);

      $stmt->execute();
      return $stmt->fetch();
    }

    public function findAllRooms() {
      $stmt = $this->conn->prepare("SELECT * FROM rooms" ) or die($this->conn->error.__LINE__);
      $stmt->setFetchMode(PDO::FETCH_ASSOC);
      
      $stmt->execute();
      return $stmt->fetchAll();
    }

    public function addRooms($arrRooms) {
      $sql = "INSERT INTO rooms (roomName, roomSeat, roomOption, isActive) values (:name, :seat, :opt, true)";
      return $this->_backMdf($arrRooms, $sql);
    }

    public function updateRooms($arrRooms) {
      $sql = "UPDATE rooms set roomName=:name, roomSeat=:seat, roomOption=:opt WHERE roomID=:rId";
      return $this->_backMdf($arrRooms, $sql);
    }


    public function deleteRooms($arrRid) {
      $sql = "DELETE from rooms WHERE roomID=:rId";
      return $this->_backMdf($arrRid, $sql);
    }



    /*============================
    * Booked handler
    ==============================*/

    public function findBooked($bId) {
      $stmt = $this->conn->prepare("SELECT * FROM bookeds WHERE bookedID = :bId" ) or die($this->conn->error.__LINE__);
      $stmt->setFetchMode(PDO::FETCH_ASSOC);
      $stmt->bindParam(':bId',$bId);

      $stmt->execute();
      return $stmt->fetch();
    }

    public function findBookedByRoom($rId) {
      $stmt = $this->conn->prepare("SELECT * FROM bookeds WHERE roomID = :rId" ) or die($this->conn->error.__LINE__);
      $stmt->setFetchMode(PDO::FETCH_ASSOC);
      $stmt->bindParam(':rId',$rId);

      $stmt->execute();
      return $stmt->fetch();
    }

    public function findBookedByUser($uId, $dateCurrent) {
      //$stmt = $this->conn->prepare("SELECT * FROM bookeds WHERE userID = :uId" ) or die($this->conn->error.__LINE__);
      $stmt = $this->conn->prepare("SELECT bookeds.*, rooms.roomName FROM bookeds INNER JOIN rooms ON bookeds.roomID = rooms.roomID WHERE userID = :uId and bookedDate >= :crrDate" ) or die($this->conn->error.__LINE__);
      $stmt->setFetchMode(PDO::FETCH_ASSOC);
      $stmt->bindParam(':uId',$uId);
      $stmt->bindParam(':crrDate',$dateCurrent);

      $stmt->execute();
      return $stmt->fetchAll();
    }

    public function findBookedRange($dateFrom, $dateEnd) {
      $stmt = $this->conn->prepare("SELECT * FROM bookeds WHERE bookedDate BETWEEN :dfrom AND :dend " ) or die($this->conn->error.__LINE__);
      $stmt->setFetchMode(PDO::FETCH_ASSOC);
      $stmt->bindParam(':dfrom',$dateFrom);
      $stmt->bindParam(':dend',$dateEnd);

      $stmt->execute();
      return $stmt->fetch();
    }

    public function findBookedCurrentDate($dateCurrent) {
      $stmt = $this->conn->prepare("SELECT bookeds.*, users.userName FROM bookeds INNER JOIN users ON bookeds.UserID = users.userID WHERE bookedDate >= :dcrr") or die($this->conn->error.__LINE__);
      
      $stmt->setFetchMode(PDO::FETCH_ASSOC);
      $stmt->bindParam(':dcrr',$dateCurrent);

      $stmt->execute();
      return $stmt->fetchAll();
    }

    public function findAllBooked() {
      $stmt = $this->conn->prepare("SELECT * FROM bookeds" ) or die($this->conn->error.__LINE__);
      $stmt->setFetchMode(PDO::FETCH_ASSOC);
      
      $stmt->execute();
      return $stmt->fetchAll();
    }

    public function addBooked($arrBooks) {
      $sql = "INSERT INTO bookeds (roomID, userID, bookedTimeStart, bookedTimeEnd, bookedTimeCompleted, bookedDate, bookedComment, bookedActive, bookedStatus) values (:rId, :uId, :bTimeStart, :bTimeEnd, :bTimeCompleted, :bDate, :bComment, :bActive, :bStatus)";
      return $this->_backMdf($arrBooks, $sql);
    }

    public function updateBooked($arrBooks) {
      $sql = "UPDATE bookeds set roomID=:rId, bookedTimeStart=:bTimeStart, bookedTimeEnd=:bTimeEnd bookedDate=:bDate bookedComment=:bComment WHERE bookedID=:bId";
      return $this->_backMdf($arrBooks, $sql);
    }


    public function deleteBooked($Bid) {
      $sql = "DELETE from bookeds WHERE bookedID=:bId";
      $arrbID = array();
      array_push($arrbID, array('bId'=>$Bid));
      return $this->_backMdf($arrbID, $sql);
    }
}
?>