<?php  
/**
 * Database configuration*/

define('DB_DNS', 'mysql:dbname=meetingroom_v2;host=localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');

// define('DB_DNS', 'mysql:dbname=_meettingroom;host=mysql521.heteml.jp');
// define('DB_USERNAME', '_meettingroom');
// define('DB_PASSWORD', 'ifv848484');
?>