 <?php

class dbConnect {

    private $connect;

    function __construct() { 
    }


    /**
     * Establishing database connection
     * @return database connection handler
     */
    function connect() {
      try {
          require_once 'configCon.php';

          // Connecting to mysql database
          $this->connect = new PDO(DB_DNS, DB_USERNAME, DB_PASSWORD);

          // returing connection resource
          return $this->connect;
      } catch (PDOException $e) {
          echo 'Connection failed: ' . $e->getMessage();
      }
    }


    /**
     * Destroy database connection
     */
    function destroy() {
      $this->connect = null;
    }
}

?>