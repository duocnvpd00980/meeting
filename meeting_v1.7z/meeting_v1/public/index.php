<?php 
header("Access-Control-Allow-Origin: *");
 header("Access-Control-Allow-Methods: PUT, GET, POST, PUT, OPTIONS, DELETE, PATCH");
 header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept, Authorization");
 header("Access-Control-Allow-Credentials: true");
?>
<?php
require 'vendor/autoload.php';
$app = new \Slim\Slim();

$app->get('/hello/:name', function ($name){
	echo "Hello, $name";
});


$app->post('/login/', function () use ($app) {
	try {
		$emailPost = $app->request->getBody();
		
		require_once'../database/dbHandler.php';
		$dbExc = new dbHandler();
		$rs = $dbExc->findUserByEmail($emailPost);
		if ($rs) {
			if($rs["userEmail"] == "thao-nv@dgw.asia") {
				$rs["userRole"] = 1;
			} else {
				$rs["userRole"] = 0;
			}
			header("Content-Type: application/json");
			echo json_encode($rs);
		} else {
		  echo ("nan");
		}
	} catch (ResourceNotFoundException $e) {
		// return 404 server error
		$app->response->status(404);
	} catch (Exception $e) {
		$app->response->status(400);
		$app->response->header('X-Status-Reason', $e->getMessage());
	}	
});

$app->get('/getUser/', function () use ($app) {
	try {
		require_once'../database/dbHandler.php';
		$dbExc = new dbHandler();
		$rs = $dbExc->findAllUsers();
		if ($rs) {
			header("Content-Type: application/json");
			echo json_encode($rs);
		} else {
		  echo ("nan");
		}
	} catch (ResourceNotFoundException $e) {
		// return 404 server error
		$app->response->status(404);
	} catch (Exception $e) {
		$app->response->status(400);
		$app->response->header('X-Status-Reason', $e->getMessage());
	}	
});

$app->post('/addUser/', function () use ($app) {
	try {
		$dataPush = json_decode($app->request->getBody()); 
		require_once'../database/dbHandler.php';
		$dbExc = new dbHandler();
		if ($dbExc->addUsers($dataPush)) {
		  header("Content-Type: application/json");
		  echo json_encode($dataPush);
		} else {
		  echo ("nan");
		}
	} catch (ResourceNotFoundException $e) {
		// return 404 server error
		$app->response->status(404);
	} catch (Exception $e) {
		$app->response->status(400);
		$app->response->header('X-Status-Reason', $e->getMessage());
	}
});

$app->put('/updateUser/', function () use ($app) {
	try {
		$dataPush = json_decode($app->request->getBody()); 
		require_once'../database/dbHandler.php';
		$dbExc = new dbHandler();
		if ($dbExc->updateUsers($dataPush)) {
		  header("Content-Type: application/json");
		  echo json_encode($dataPush);
		} else {
		  echo ("nan");
		}
	} catch (ResourceNotFoundException $e) {
		// return 404 server error
		$app->response->status(404);
	} catch (Exception $e) {
		$app->response->status(400);
		$app->response->header('X-Status-Reason', $e->getMessage());
	}
});



$app->get('/getRoom/', function () use ($app) {
	try {
		require_once'../database/dbHandler.php';
		$dbExc = new dbHandler();
		$rs = $dbExc->findAllRooms();
		if ($rs) {
		  header("Content-Type: application/json");
		  echo json_encode($rs);
		} else {
		  echo ("nan");
		}
	} catch (ResourceNotFoundException $e) {
		// return 404 server error
		$app->response->status(404);
	} catch (Exception $e) {
		$app->response->status(400);
		$app->response->header('X-Status-Reason', $e->getMessage());
	}
});


$app->post('/addRoom/', function () use ($app) {
	try {
		$dataPush = json_decode($app->request->getBody()); 
		require_once'../database/dbHandler.php';
		$dbExc = new dbHandler();
		if ($dbExc->addRooms($dataPush)) {
		  header("Content-Type: application/json");
		  echo json_encode($dataPush);
		} else {
		  echo ("nan");
		}
	} catch (ResourceNotFoundException $e) {
		// return 404 server error
		$app->response->status(404);
	} catch (Exception $e) {
		$app->response->status(400);
		$app->response->header('X-Status-Reason', $e->getMessage());
	}
});


$app->put('/updateRoom/', function () use ($app) {
	try {
		$dataPush = json_decode($app->request->getBody()); 
		require_once'../database/dbHandler.php';
		$dbExc = new dbHandler();
		if ($dbExc->updateRooms($dataPush)) {
		  header("Content-Type: application/json");
		  echo json_encode($dataPush);
		} else {
		  echo ("nan");
		}
	} catch (ResourceNotFoundException $e) {
		// return 404 server error
		$app->response->status(404);
	} catch (Exception $e) {
		$app->response->status(400);
		$app->response->header('X-Status-Reason', $e->getMessage());
	}
});



$app->get('/getAllBook/', function () use ($app) {
	try {
		require_once'../database/dbHandler.php';
		$dbExc = new dbHandler();
		$rs = $dbExc->findAllBooked();
		if ($rs) {
		  header("Content-Type: application/json");
		  echo json_encode($rs);
		} else {
		  echo ("nan");
		}
	} catch (ResourceNotFoundException $e) {
		// return 404 server error
		$app->response->status(404);
	} catch (Exception $e) {
		$app->response->status(400);
		$app->response->header('X-Status-Reason', $e->getMessage());
	}
});

$app->get('/getAllBook/:uId/:crrdate', function ($uId,$crrdate) use ($app) {
	try {
		require_once'../database/dbHandler.php';
		$dbExc = new dbHandler();

		$rs = $dbExc->findBookedByUser($uId, $crrdate);
		if ($rs) {
		  header("Content-Type: application/json");
		  echo json_encode($rs);
		} else {
		  echo ("nan");
		}
	} catch (ResourceNotFoundException $e) {
		$app->response->status(404);
	} catch (Exception $e) {
		$app->response->status(400);
		$app->response->header('X-Status-Reason', $e->getMessage());
	}
});


$app->get('/getCurrentDateBook/:crrdate', function ($crrdate) use ($app) {
	try {
		require_once'../database/dbHandler.php';
		$dbExc = new dbHandler();
		
		$rs = $dbExc->findBookedCurrentDate($crrdate);
		if ($rs) {
		  header("Content-Type: application/json");
		  echo json_encode($rs);
		} else {
		  echo ("nan");
		}
	} catch (ResourceNotFoundException $e) {
		// return 404 server error
		$app->response->status(404);
	} catch (Exception $e) {
		$app->response->status(400);
		$app->response->header('X-Status-Reason', $e->getMessage());
	}
});


$app->post('/addBook/', function () use ($app) {
	try {
		$dataPush = json_decode($app->request->getBody()); 
		require_once'../database/dbHandler.php';
		$dbExc = new dbHandler();
		if ($dbExc->addBooked($dataPush)) {
		  header("Content-Type: application/json");
		  echo json_encode($dataPush);
		} else {
		  echo ("nan");
		}
	} catch (ResourceNotFoundException $e) {
		// return 404 server error
		$app->response->status(404);
	} catch (Exception $e) {
		$app->response->status(400);
		$app->response->header('X-Status-Reason', $e->getMessage());
	}
});


$app->delete('/delBooked/:bId', function ($bId) use ($app) {
    try {
		require_once'../database/dbHandler.php';
		$dbExc = new dbHandler();
		if ($dbExc->deleteBooked($bId)) {
		  echo ("deleted");
		}
	} catch (ResourceNotFoundException $e) {
		// return 404 server error
		$app->response->status(404);
	} catch (Exception $e) {
		$app->response->status(400);
		$app->response->header('X-Status-Reason', $e->getMessage());
	}
});




$app->run();
?>