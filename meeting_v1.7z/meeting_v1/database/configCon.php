<?php  
/**
 * Database configuration*/

echo "connect database"

define('DB_DNS', 'mysql:dbname=meetingroom_v2;host=localhost:82');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'root');

// define('DB_DNS', 'mysql:dbname=_meettingroom;host=mysql521.heteml.jp');
// define('DB_USERNAME', '_meettingroom');
// define('DB_PASSWORD', 'ifv848484');
?>

