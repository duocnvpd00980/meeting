<?php
	class booked {
		public $bookedID;
		public $roomID;
		public $userID;
		public $bookedTimeStart;
		public $bookedTimeEnd;
		public $bookedTimeCompleted;
		public $bookedDate;
		public $bookedComment;
		public $bookedActive;
		public $bookedStatus;
		public $created;
	}


	class room {
		public $roomID;
		public $roomName;
		public $roomSeat;
		public $roomOption;
		public $created;
	}


	class User {
		public $userID;
		public $userName;
		public $userEmail;
		public $userDep;
		public $created;
	}
?>