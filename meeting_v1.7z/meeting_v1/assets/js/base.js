/* XXXXXX
=========================================== */
	var XXXXXX = {
		setInit : function(){
			
		}
	}

/* calendar control
=========================================== */
	var currentMonthView = new Date().getMonth();
	var currentYearView = (new Date).getFullYear();
	var newCalendar = "";
	var calendarControl = {
		setInit : function(){
			//current month load
			calendarControl.renderCalendar();

			// next load
			$(".prev-month").click(function(){
				if (currentMonthView  == 0) {
					currentYearView--;	
					currentMonthView = 11;
				} else {
					currentMonthView--;
				}
				calendarControl.renderCalendar();
			});

			// prev load
			$(".next-month").click(function(){
				if (currentMonthView  == 11) {
					currentYearView++;
					currentMonthView = 0;
				} else {
					currentMonthView++;
				}
				calendarControl.renderCalendar();
			});
		},
		renderCalendar : function() {
			newCalendar = calendar(currentYearView,currentMonthView);
			$(".book-calendar_table").html(newCalendar);
		}
	}



$(document).ready(function(){
	calendarControl.setInit();
}); 


/* ===========================================
calendar lib
=========================================== */	
calendarTemplate = "\
		<div class='info'>{{monthName}} {{year}}</div>			\
		<table class='tbl-calendar'>                            \
	        <tr>                                                \
	            <th>Sun</th>                                    \
	            <th>Mon</th>                                    \
	            <th>Tue</th>                                    \
	            <th>Wed</th>                                    \
	            <th>Thu</th>                                    \
	            <th>Fri</th>                                    \
	            <th>Sat</th>                                    \
	        </tr>                                               \
	        {{days}}                                            \
	    </table>                                                \
	    ";
calendar = function(year,month){
	currentDate = new Date().getDate();
	currentMonth = new Date().getMonth(); 
	currentYear = (new Date).getFullYear()
	rowStart= "<tr>";
	rowEnd = "</tr>";
	cellStart = "<td>";
	cellStartCurent = "<td class='current'>";
	cellEnd = "</td>";

    var tmpl=function(a,b){return a.replace(/\{\{([^{}]+)}}/g,function(c,d){return typeof b[d]=="function"?b[d]():b[d]})}

    return tmpl(calendarTemplate,{
        monthName:"January,February,March,April,May,June,July,August,September,October,November,December".split(",")[month],
        year:year,
        days:function(f,txt,i){
            f   =  (new Date(year,month,1)).getDay()+1
            txt =  ""
            for(i=1;i<[31,(year%4?28:29),31,30,31,30,31,31,30,31,30,31][month]+f;i++){
            	if((currentDate + (new Date(year,month,1)).getDay()) == i && month == currentMonth && year == currentYear){
            		txt+=(i%7==1?rowStart:"")+cellStartCurent+(i<f?"":i-f+1)+cellEnd+(i%7==7?rowEnd:"");	
            	}
            	else {
            		txt+=(i%7==1?rowStart:"")+cellStart+(i<f?"":i-f+1)+cellEnd+(i%7==7?rowEnd:"");	
            	}
            }
            return txt
        }
    });
}




