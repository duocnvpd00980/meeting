/*==============
  Router App
================*/


var mainApp = angular.module('mainApp', ['ui.router','toastr', 'ngCookies']);

mainApp.config(function($stateProvider, $urlRouterProvider, $httpProvider) {
    $urlRouterProvider.otherwise('home');
    $stateProvider
        .state('home', {
            url: '/',
            templateUrl : 'pages/home.html',
            controller  : 'topController'
        }).state('login', {
            url: '/login',
            templateUrl : 'pages/login.html',
            controller  : 'loginController'
        }).state('logout', {
            url: '/logout',
            templateUrl : '',
            controller  : 'logoutController'
        }).state('list-booked', {
            url: '/list-booked',
            templateUrl : 'pages/booked_list.html',
            controller  : 'listBookedController'
        }).state('create-room', {
            url: '/create-room',
            templateUrl : 'pages/room_create.html',
            controller  : 'createRoomController'
        }).state('list-room', {
            url: '/list-room',
            templateUrl : 'pages/room_list.html',
            controller  : 'listRoomController'
        }).state('create-user', {
            url: '/create-user',
            templateUrl : 'pages/user_create.html',
            controller  : 'createUserController'
        }).state('list-user', {
            url: '/list-user',
            templateUrl : 'pages/user_list.html',
            controller  : 'listUserController'
        });
  $httpProvider.defaults.headers.common = {};
  $httpProvider.defaults.headers.post = {};
  $httpProvider.defaults.headers.put = {};
  $httpProvider.defaults.headers.patch = {};
});

mainApp.config(function(toastrConfig) {
  angular.extend(toastrConfig, {
    autoDismiss: false,
    containerId: 'toast-container',
    maxOpened: 0,    
    newestOnTop: true,
    positionClass: 'toast-bottom-full-width',
    preventDuplicates: false,
    preventOpenDuplicates: false,
    target: 'body'
  });
});


mainApp.run(function ($rootScope, $location, $cookies) {
  $rootScope.$on('$locationChangeStart', function (event, next, current) {
      // redirect to login page if not logged in
      $rootScope.globals = $cookies.getObject('globals') || {};
      var loggedIn = $rootScope.globals.currentUser;

      if (!loggedIn) {
        $location.path('/login');
      } else {
        $rootScope.uName = loggedIn.name;
        $rootScope.uEmail = loggedIn.email;
        $rootScope.isAdmin = loggedIn.role;
        $rootScope.crrUId = loggedIn.id;
        $rootScope.authenticated = true;
      }
  });
});

mainApp.controller('loginController', function($scope, $rootScope, $http, $location, $cookies, toastr) {
  $scope.checkLogin = function(loginForm){
    if($scope[loginForm].$valid){
      $http.post("/public/login/", $scope.emailCheck,{headers: {'Content-Type': 'type; charset=utf-8'}
      }).then(function successCallback(response) {
        var uData = response.data;
        if ($scope.emailCheck == uData.userEmail) {
           $rootScope.globals = {
                currentUser: {
                    name: uData.userName,
                    email: uData.userEmail,
                    id: uData.userID,
                    role: uData.userRole
                }
            };
 
            // store user details in globals cookie that keeps user logged in for 1 day (or until they logout)
            var cookieExp = new Date();
            cookieExp.setDate(cookieExp.getDate() + 1);
            $cookies.putObject('globals', $rootScope.globals, { expires: cookieExp });
            $location.path('/');
        } else {
          toastr.error('Incorrect Email !');
        }
      });
    } else {
      // view notify
      toastr.warning('please fill Email correctly !');
    }
  }
});

mainApp.controller('logoutController', function($scope, $rootScope, $cookies) {
  $rootScope.globals = {};
  $cookies.remove('globals');
  $rootScope.uName = "";
  $rootScope.uEmail = "";
  $rootScope.crrUId = "";
  $rootScope.isAdmin = 0;
  $rootScope.authenticated = false;
  $location.path('/login');
});



mainApp.controller('topController', function($scope, $rootScope, $http, $filter, $location, toastr) {
  $scope.$on('$viewContentLoaded', function() {
    // bind list Room
    $http.get("/public/getRoom/").then(function(response) {
         $scope.allRooms = response.data;
    });

    // set default value
    $scope.bindBookedList();
    $scope.resetForm();
    $scope.bookFromToday = "";
  });

  $scope.bindBookedList = function(){ 
    // get book from today
    var crrDateBook = moment().format('YYYY-MM-DD');
    $http.get("/public/getCurrentDateBook/"+crrDateBook).then(function(response) {
      $scope.bookFromToday = response.data;
      $scope.bookFromTodayTemp = angular.copy($scope.bookFromToday);
    });
  }
  
  $scope.resetForm = function(){
    $scope.dayBooked = moment();
    $scope.timeHourStart = "06";
    $scope.timeHourEnd = "06";
    $scope.timeMinStart = "00";
    $scope.timeMinEnd = "00";
    $scope.bookComment = "";  
  }


  $scope.roomViewBook = function(row){
    $scope.roomSelect = {'name':row.roomName, 'id':row.roomID};
    var tempBookeList = $filter('filter')($scope.bookFromTodayTemp, function(item) {
          return item.roomID == row.roomID;
    });
    $scope.bookFromToday = tempBookeList;

    // reset booked list
    $scope.bindBookedThisDate();
  }

  
  $scope.bindBookedThisDate = function() {
    var bookDateSelect = $scope.dayBooked.format('YYYY-MM-DD');
    var tempBookeList = $filter('filter')($scope.bookFromToday, function(item) {
      return (item.bookedDate == bookDateSelect);
    });
    $scope.listBookedSelected = tempBookeList;
  };

  // add Book proccess
  $scope.addBook = function(bForm){
    // declare time star end
    var startMin = (parseInt($scope.timeHourStart) * 60) + parseInt($scope.timeMinStart);
    var endMin = (parseInt($scope.timeHourEnd) * 60) + parseInt($scope.timeMinEnd);

    // check book time 
    var timeCorrect = false;
    var timeOverlap = false;
    var dateBookVail = false;
    
    // check Overlap Time
    angular.forEach($scope.listBookedSelected, function(value1, key1) {
      var startMinItems = (parseInt(value1.bookedTimeStart.slice(0,2)) * 60) + (parseInt(value1.bookedTimeStart.slice(3,5)));
      var endMinItems = (parseInt(value1.bookedTimeEnd.slice(0,2)) * 60) + (parseInt(value1.bookedTimeEnd.slice(3,5)));
      if((startMin > startMinItems && startMin < endMinItems) || (endMin > startMinItems && endMin < endMinItems) || (startMin <= startMinItems && endMin >= endMinItems)) {
        timeOverlap = true;
      }
    });


    // check daybook after curent day
    var currentDateTime = moment();
    var fullDateTimeBooked = moment($scope.dayBooked.format('YYYY-MM-DD') + " " + $scope.timeHourStart + ":" + $scope.timeMinStart);


    if(currentDateTime > fullDateTimeBooked) {
      toastr.error('You can not book the room in the past!');
    } else if (startMin >= endMin) {
      toastr.error('Start time must be smaller than End time !');
    } else if(timeOverlap){
      toastr.error('The room is not available at your required time!');
    } else if($scope[bForm].$valid){
      var dataPush = [{'rId':'', 'uId':'', 'bTimeStart':'', 'bTimeEnd':'', 'bTimeCompleted':'', 'bDate':'', 'bComment':'', 'bActive': 1, 'bStatus': 0}]
      dataPush[0].rId = $scope.roomSelect.id;
      dataPush[0].uId = $rootScope.crrUId;
      dataPush[0].bTimeStart = $scope.timeHourStart +':'+ $scope.timeMinStart +':00';
      dataPush[0].bTimeEnd = $scope.timeHourEnd +':'+ $scope.timeMinEnd +':00';
      dataPush[0].bTimeCompleted = $scope.timeHourEnd +':'+ $scope.timeMinEnd +':00';
      dataPush[0].bDate = $scope.dayBooked.format('YYYY-MM-DD');
      dataPush[0].bComment = $scope.bookComment;

      $http.post("/public/addBook/", dataPush,{headers: {'Content-Type': 'application/json; charset=utf-8'}
      }).then(function successCallback(response) {
        if(response.data == "nan" && response.data){
          toastr.error(response.data + 'Please fill in all the information !');
        }
        else {
          // view notify
          //toastr.success(' your booked at '+ $scope.roomSelect.name +' room successfull !');
          toastr.success(' Your booking for Room '+ $scope.roomSelect.name +' has been made successfully!');
          $scope.resetForm();
          $scope.bindBookedList();

          // close windowns use jquery
          $("#bookRoom .close").trigger("click");
        }
      });
    } else {
      toastr.error('Please fill in all the information !');
    }
  }
});


mainApp.controller('listBookedController', function($scope, $rootScope, $http, $filter, toastr) {
  $scope.listBoookedbyUsers = "" ;

  var crrDateBook = moment().format('YYYY-MM-DD');
  $http.get("/public/getAllBook/"+$rootScope.crrUId+"/"+crrDateBook).then(function(response) {
      $scope.listBoookedbyUsers = response.data;
  });

  $scope.deleteBooked = function(bookedObj,key){
    var bookDelID = bookedObj.bookedID;
    $http.delete("/public/delBooked/"+bookDelID,{headers: {'Content-Type': 'application/json; charset=utf-8'}
      }).then(function (response) {
      if (response.data) {
        var newListBook = $filter('filter')($scope.listBoookedbyUsers, function(item) {
          return item.bookedID != bookDelID;
        });
        $scope.listBoookedbyUsers = newListBook;
        toastr.success('Your booking has been removed successfully!');
      }
    }, function (response) {
        toastr.error('removed can not execute !');
        console.log(response)
    });
  }
});




mainApp.controller('createUserController', function($scope, $http, toastr) {
    $scope.userName = "";
    $scope.userEmail = "";
    $scope.userDep = "";

    $http.get("/public/getUser/").then(function(response) {
      $scope.allUsers = response.data;
    });

    $scope.rowUsers = [{'name':'','email':'','dep':''}];
    $scope.addRow = function(){
        $scope.rowUsers.push({'name':'','email':'','dep':''}); 
    }
    $scope.removeRow = function(){
        var lastItem = $scope.rowUsers.length-1;
        $scope.rowUsers.splice(lastItem);
    }
    $scope.insertUser = function(uform){

        var checkEmail = false;
        angular.forEach($scope.rowUsers, function(value1, key1) {
            angular.forEach($scope.allUsers, function(value2, key2) {
                if(value1.email == value2.userEmail) {
                    checkEmail = true;
                }
            });
        });

        if(checkEmail) {
          toastr.error('The Emails exists!');
        } else if($scope[uform].$valid && $scope.rowUsers.length > 0){
            
            $http.post("/public/addUser/", $scope.rowUsers,{headers: {'Content-Type': 'application/json; charset=utf-8'}
            }).then(function successCallback(response) {
              if(response.data == "nan"){
                toastr.error('Please fill in all the information !');
              }
              else {
                // reset form
                $scope.rowUsers = [{'name':'','email':'','dep':''}];

                // view notify
                toastr.success('Your user has been created successfully!');
              }
            });
        } else {
          // view notify
          toastr.error('Please fill in all the information !');
        }
    };
});


mainApp.controller('listUserController', function($scope, $http, $filter, toastr) {
    $scope.allUsers = "" ;
    $scope.UserTemp = "";
    $http.get("/public/getUser/").then(function(response) {
        $scope.allUsers = response.data;
        $scope.UserTemp = angular.copy($scope.allUsers);
    });

    $scope.editUser = function(objRow){
        objRow.editMode = true;
    }
    $scope.resetUserMode = function(objRow){
        var objReset = $filter('filter')($scope.UserTemp, function(item) {
          return item.userID == objRow.userID;
        })[0];
        objRow.userName = objReset.userName;
        objRow.userEmail = objReset.userEmail;
        objRow.userDep = objReset.userDep;
        objRow.editMode = false;
    }
    $scope.saveUser = function(objRow, uForm){ 
       if($scope[uForm].$valid) {
        var dataPush = [{'name':objRow.userName,'email':objRow.userEmail,'dep':objRow.userDep,'uId': objRow.userID}];

        $http.put("/public/updateUser/", dataPush,{headers: {'Content-Type': 'application/json; charset=utf-8'}
        }).then(function successCallback(response) {
            // set default
            objRow.editMode = false;
            $scope.UserTemp = angular.copy($scope.allUsers);

            // view notify
            toastr.success('The information changed has been save successfully!');
        }, function (response) {
            toastr.error('Update can not execute !');
        });
      } else {
        // view notify
        toastr.warning('Please fill in all the information !');
      }
    }
});




mainApp.controller('createRoomController', function($scope, $http, toastr) {
    $scope.roomName = "";
    $scope.roomSeat = 1;
    $scope.insertRoom = function(rform){
        if($scope[rform].$valid){
            var roomData = [{'name':$scope.roomName,'seat':$scope.roomSeat,'opt':''}];
            $http.post("/public/addRoom/", roomData,{headers: {'Content-Type': 'application/json; charset=utf-8'}
            }).then(function successCallback(response) {
                // reset form
                $scope.roomName = "";
                $scope.roomSeat = 1;
                $scope.roomForm.$setPristine();
                $scope.roomForm.$setUntouched();

                // view notify
                toastr.success('the Room has been created successfully!');
            });
        } else {
          // view notify
          toastr.error('Please fill in all the information !');
        }
    };
});

mainApp.controller('listRoomController', function($scope, $http, $filter, toastr) {
  $scope.allRooms = "" ;
  $scope.RoomTemp = "";
  $http.get("/public/getRoom/").then(function(response) {
      $scope.allRooms = response.data;
      $scope.RoomTemp = angular.copy($scope.allRooms);
  });
  $scope.parseRoomSeat = function(objRow){
    objRow.roomSeat = parseInt(objRow.roomSeat);
  }
  $scope.editRoom = function(objRow){
      objRow.editMode = true;
  }
  $scope.resetRoomMode = function(objRow){
      var objReset = $filter('filter')($scope.RoomTemp, function(item) {
        return item.roomID == objRow.roomID;
      })[0];
      objRow.roomName = objReset.roomName;
      objRow.roomSeat = parseInt(objReset.roomSeat);
      objRow.editMode = false;
  }
  $scope.saveRoom = function(objRow, rForm){ 
      if($scope[rForm].$valid) {
        var dataPush = [{'name':objRow.roomName,'seat':objRow.roomSeat,'opt':'Nan','rId':objRow.roomID}];
        $http.put("/public/updateRoom/", dataPush, {headers: {'Content-Type': 'application/json; charset=utf-8'}
        }).then(function successCallback(response) {
          // set default
          objRow.editMode = false;
          $scope.RoomTemp = angular.copy($scope.allRooms);

          // view notify
          toastr.success('The information changed has been save successfully!');
        });
      } else {
        // view notify
        toastr.warning('Please fill in all the information !');
      }
  }
});




/*Factory Directive */
mainApp.directive('calendar', function($timeout) {
  return {
    restrict: "E",
    templateUrl: "/app/directive_template/calendar.html",
    scope: {
      selected: "=",
      listBooked: "=",
      dateSelectBook: '&'
    },
    link: function(scope, ctrl) {

      scope.select = function(day) {
        scope.selected = day.date;
        $timeout(function() {
          scope.dateSelectBook();
        }, 500);
      };
      
      scope.next = function() {
        var next = scope.month.clone();
        _removeTime(next.month(next.month()+1).date(1));
        scope.month.month(scope.month.month()+1);
        _buildMonth(scope, next, scope.month);
      };

      scope.previous = function() {
        var previous = scope.month.clone();
        _removeTime(previous.month(previous.month()-1).date(1));
        scope.month.month(scope.month.month()-1);
        _buildMonth(scope, previous, scope.month);
      };

      
      scope.$watch(function() { return scope.listBooked; }, function(newVal, oldVal) {
          if (newVal && newVal !== oldVal) {
            //scope.selected = _removeTime(scope.selected || moment());
            scope.month = scope.selected.clone();
            var start = scope.selected.clone();
            start.date(1);
            _removeTime(start.day(0));
            _removeTime(start.day(0));
            _buildMonth(scope, start, scope.month);
          }
      });
    }
  };

  function _removeTime(date) {
    return date.day(0).hour(0).minute(0).second(0).millisecond(0);
  }

  function _buildMonth(scope, start, month) {
    scope.weeks = [];
    var done = false, date = start.clone(), monthIndex = date.month(), count = 0;
    while (!done) {
      scope.weeks.push({ days: _buildWeek(date.clone(), month, scope) });
      date.add(1, "w");
      done = count++ > 2 && monthIndex !== date.month();
      monthIndex = date.month();
    }
  }

  function _buildWeek(date, month, scope) {
    var days = [];

    for (var i = 0; i < 7; i++) {
      days.push({
        name: date.format("dd").substring(0, 1),
        number: date.date(),
        isCurrentMonth: date.month() === month.month(),
        isToday: date.isSame(new Date(), "day"),
        isBook: _checkBookedDate(date, scope),
        date: date
      });

      date = date.clone();
      date.add(1, "d");
     }
    return days;
  }

  function _checkBookedDate(date, scope) {
      var tempRs = false;
      angular.forEach(scope.listBooked, function(item){
        var dateBooked = moment(item.bookedDate);
        if(date.year() === dateBooked.year() && date.month() === dateBooked.month() && date.date() === dateBooked.date()) {
          tempRs = true;    
        }
      });
      return tempRs;
   }

});